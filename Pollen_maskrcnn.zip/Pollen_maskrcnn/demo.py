import cv2
import mrcnn.model as modellib
import pandas as pd
from mrcnn.visualize import InferenceConfig, get_mask_contours, random_colors, draw_mask
import numpy as np
import diplib as dip
import glob
import os

# Load image
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
path = "images/template.jpg"
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
img = cv2.imread(path)
image = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

# Load Mask-RCNN
config = InferenceConfig(num_classes=2, image_size=1024)
model = modellib.MaskRCNN(mode="inference", config=config, model_dir="")
# Please make sure that the weight file is placed in the correct path
model.load_weights(filepath="dnn_model/mask_rcnn_pollen_detect.h5", by_name=True)
out_path = './output/'

# Load classes
classes = []
with open("dnn_model/classes.txt", "r") as file_object:
    for class_name in file_object.readlines():
        class_name = class_name.strip()
        classes.append(class_name)
def apply_mask_black(image, mask):
    image[:, :, 0] = np.where(
        mask == 0,
        0,
        255
    )
    image[:, :, 1] = np.where(
        mask == 0,
        0,
        255
    )
    image[:, :, 2] = np.where(
        mask == 0,
        0,
        255
    )
    return image


# This function is used to show the object detection result in original image.
def display_instances(image, boxes, masks, ids, names, scores):
    # max_area will save the largest object for all the detection results
    max_area = 0

    # n_instances saves the amount of all objects
    n_instances = boxes.shape[0]

    if not n_instances:
        print('NO INSTANCES TO DISPLAY')
    else:
        assert boxes.shape[0] == masks.shape[-1] == ids.shape[0]
    mask = np.array([0])
    # mask = False
    # print(image.shape)
    mask = np.zeros(image[:, :, 0].shape)

    for i in range(n_instances):
        if not np.any(boxes[i]):
            continue

        # compute the square of each object
        y1, x1, y2, x2 = boxes[i]
        square = (y2 - y1) * (x2 - x1)

        label = names[ids[i]]
        if label == 'tube':
            # save the largest object in the image as main character
            # other people will be regarded as background
            # if square > max_area:
            # max_area = square
            # print(masks[:, :, i].shape)
            mask += masks[:, :, i]
        # else:
        # continue
        else:
            continue

    for i in range(mask.shape[0]):
        for j in range(mask.shape[1]):
            if mask[i, j] > 0:
                mask[i, j] = 255
    # apply mask for the image
    # by mistake you put apply_mask inside for loop or you can write continue in if also

    image = apply_mask_black(image, mask)
    return image if not mask.sum() == 0 else mask
    # return image
def img_black(image_path):
    images_list = []
    images_list.append(image_path)
    for name in sorted(images_list):
        original_image = name
        image = cv2.imread(original_image)
        # gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        results = model.detect([image], verbose=0)
        r = results[0]
        frame = display_instances(image, r['rois'], r['masks'], r['class_ids'], classes, r['scores'])

        if frame.sum() == 0:
            continue
        else:
            output_dir = out_path+'black/'
            #os.mkdir(output_dir)
            name = name.split("/")
            name = name[len(name)-1]
            cv2.imwrite(output_dir+name,frame)
            # cv2.imshow("img",frame)
            # cv2.waitKey(0)

# Detect objects
result = model.detect([image])[0]
class_ids = result["class_ids"]
object_count = len(class_ids)

# Number counting
type_dict = {1: "grain:", 2: "tube:"}
number = pd.value_counts(class_ids).rename(index=type_dict)
print(number)

# Random colors
colors = random_colors(object_count)

for i in range(object_count):
    # 1. Class ID
    class_id = result["class_ids"][i]
    # 2. Box
    box = result["rois"][i]
    y1, x1, y2, x2 = box

    class_name = classes[class_id]
    cv2.rectangle(img, (x1, y1), (x2, y2), colors[i], 2)
    cv2.putText(img, class_name, (x1, y1 - 5), cv2.FONT_HERSHEY_PLAIN, 1, colors[i], 1)

    # 3. Score
    score = result["scores"][i]

    # 4.Mask
    mask = result["masks"][:, :, i]
    # print(mask)
    contours = get_mask_contours(mask)
    # print(contours)
    for cnt in contours:
         cv2.polylines(img, [cnt], True, colors[i], 2)
         img = draw_mask(img, [cnt], colors[i], alpha=0.5)

# Display image
name = path.split("/")
name = name[len(name) - 1]
output_dir = out_path+"color/"
cv2.imwrite(output_dir+name,img)
# cv2.imshow("Img", img)
# cv2.waitKey(0)
img_black(path)

# ~~~~~~~~~~~~~~~~~~~~~~~
files_path = os.path.join(out_path+'black/', '*')
files = sorted(glob.iglob(files_path), key=os.path.getctime, reverse=True)
# print (files[0]) #latest file

# Skeletonization
img_grey = cv2.imread(files[0], cv2.IMREAD_GRAYSCALE)
afterMedian = cv2.medianBlur(img_grey, 3)
thresh = 140

bin = afterMedian > thresh
sk = dip.EuclideanSkeleton(bin, endPixelCondition='two neighbors')

# dip.viewer.Show(sk)
# dip.viewer.Spin()

sk = np.array(sk)
sk = np.array(sk, dtype=np.uint8)
sk *= 255
# ~~~~~~~~~~~~~~~~~~~~~~~

# cv2.imshow("Img", sk)
# Pixels counting
number_of_white_pix = np.sum(sk == 255)
print('Number of white pixels:', number_of_white_pix)

name = path.split("/")
name = name[len(name) - 1]
output_dir = out_path+"skeletonization/"
cv2.imwrite(output_dir+name, sk)

print('Detection complete.')